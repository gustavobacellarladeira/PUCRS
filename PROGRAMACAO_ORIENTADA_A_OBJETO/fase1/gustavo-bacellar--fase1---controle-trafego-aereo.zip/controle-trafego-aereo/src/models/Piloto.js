class Piloto {
  constructor(matricula, nome, habilitacaoAtiva) {
    this.matricula = matricula;
    this.nome = nome;
    this.habilitacaoAtiva = habilitacaoAtiva;
  }
}

module.exports = Piloto;
