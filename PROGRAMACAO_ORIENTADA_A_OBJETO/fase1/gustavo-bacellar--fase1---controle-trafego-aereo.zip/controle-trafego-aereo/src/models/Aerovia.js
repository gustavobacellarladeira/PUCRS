class Aerovia {
  constructor(identificador, aeroportoOrigem, aeroportoDestino, tamanho) {
    this.identificador = identificador;
    this.aeroportoOrigem = aeroportoOrigem;
    this.aeroportoDestino = aeroportoDestino;
    this.tamanho = tamanho;
  }
}

module.exports = Aerovia;
