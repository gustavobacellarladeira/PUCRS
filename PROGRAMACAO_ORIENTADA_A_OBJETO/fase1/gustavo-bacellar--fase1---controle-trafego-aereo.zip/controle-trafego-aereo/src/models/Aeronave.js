class Aeronave {
  constructor(prefixo, tipo, velocidadeCruzeiro, autonomia) {
    this.prefixo = prefixo;
    this.tipo = tipo;
    this.velocidadeCruzeiro = velocidadeCruzeiro;
    this.autonomia = autonomia;
  }
}

module.exports = Aeronave;
